

### 所有实体类之间的关系:

![image-20220606143537701](C:\Users\86133\AppData\Roaming\Typora\typora-user-images\image-20220606143537701.png)

### 自关联关系:

![image-20220606144629714](C:\Users\86133\AppData\Roaming\Typora\typora-user-images\image-20220606144629714.png)

​		子评论要继承父评论

Blog类:

![image-20220606145738480](C:\Users\86133\AppData\Roaming\Typora\typora-user-images\image-20220606145738480.png)