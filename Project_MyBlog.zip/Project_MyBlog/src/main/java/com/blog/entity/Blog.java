package com.blog.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Blog {
    private Long id;
    private String title;
    private Long userId;
    private String content;
    private String firstPicture;
    private Integer views;
    private boolean AllowComment;
    private boolean recommend;
    private boolean published;//博客处于发布还是草稿状态
    private Date UpdateTime;
    private Type type;//类型
    private User user;//作者
    private  String typeName;//类型名
    private List<Comment> Comments=new ArrayList<>();
}
