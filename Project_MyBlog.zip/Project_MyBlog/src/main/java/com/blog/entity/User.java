package com.blog.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.tomcat.util.security.MD5Encoder;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private String username;
    private String password;
    private Long id;
    private Long blog_save;
    private String nickname;
    private String avatar;
    private Integer Type;//用户类型
    private Date createTime;

    private List<Blog> MyBlogs=new ArrayList<>();

}
