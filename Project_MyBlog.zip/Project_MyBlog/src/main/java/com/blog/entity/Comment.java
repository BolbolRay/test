package com.blog.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Comment {
    private Long id;
    private String nickname;
    private String content;
    private String avatar;//头像
    private Date createTime;
    private Blog blog;
    private List<Comment> replycomments=new ArrayList<Comment>();
    private Comment parentcomment;
}
