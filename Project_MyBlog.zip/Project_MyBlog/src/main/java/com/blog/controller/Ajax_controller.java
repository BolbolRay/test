package com.blog.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class Ajax_controller {
    /*
    @Autowired
    private BlogService blogService;
    @RequestMapping(value = "/search",method = RequestMethod.GET)
    public Object Search(@RequestParam("Key") String Key,@RequestParam(required = false,defaultValue = "1",value = "pagenum")int pagenum,
                         Model model){
        PageHelper.startPage(pagenum, 8);  //开启分页
        List<Blog> blogs = blogService.getAllBlog();
        PageInfo<Blog> pageInfo = new PageInfo<>(blogs);
       // model.addAttribute("pageInfo", pageInfo);
        return pageInfo;
    }
*/
}
