package com.blog.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.net.http.HttpRequest;

//用于拦截所有的异常信息
@ControllerAdvice
public class ExceptionControllerHandler {
    private final Logger logger= LoggerFactory.getLogger(this.getClass());
        //异常注解,Exception.class代表能拦截所有的异常类，也可以指定异常如RuntimeException
        @ExceptionHandler(Exception.class)
        public ModelAndView exceptionHandle(HttpServletRequest request, Exception e) {
            //记录异常信息的日志
            logger.error("Request URL: {}, Exception : {}",request.getRequestURL(),e);
            ModelAndView mv = new ModelAndView();
            mv.addObject("url",request.getRequestURL());
            mv.addObject("exception",e);
            mv.setViewName("error/error");
            return mv;
        }
}
