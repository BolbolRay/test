package com.blog.controller;

import com.blog.entity.Blog;
import com.blog.entity.Type;
import com.blog.entity.User;
import com.blog.service.BlogService;
import com.blog.service.TypeService;
import com.blog.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.net.http.HttpRequest;
import java.sql.Types;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/Admin")
public class admin_controller {
    @Autowired
    private BlogService blogService;
    @Autowired
    private UserService userService;

    @GetMapping({"/",""})
    public String ToLogin(HttpSession session, Model model, ModelAndView MAD){
        //加入拦截器
        Object loginUser= session.getAttribute("user");
        model.addAttribute("user",loginUser);
        if (loginUser != null) {
            return "Admin/Add";
        }
        else {
            return "Admin/login";
        }
    }
    @GetMapping("LastPage/{currentpage}")
    public String LastPage(@PathVariable int currentpage,Model model){
        currentpage--;
        PageHelper.startPage(currentpage, 6);//开启分页
        List<Blog> blogs = blogService.getAllBlog();
        PageInfo<Blog> pageInfo = new PageInfo<>(blogs);
        Long Pages;
        if(pageInfo.getTotal()%6==0){
            Pages = pageInfo.getTotal()/6;
        }
        else {
            Pages = pageInfo.getTotal() / 6+1;
        }
        model.addAttribute("currentpage",currentpage);
        model.addAttribute("pages",Pages);
        model.addAttribute("pageInfo", pageInfo);
        return "Admin/Edit";
    }
    @GetMapping("/NextPage/{currentpage}")
    public String NextPage(@PathVariable int currentpage,Model model){
        currentpage++;
        PageHelper.startPage(currentpage,6);//开启分页
        List<Blog> blogs = blogService.getAllBlog();
        PageInfo<Blog> pageInfo = new PageInfo<>(blogs);
        Long Pages;
        if(pageInfo.getTotal()%6==0){
            Pages = pageInfo.getTotal()/6;
        }
        else {
            Pages = pageInfo.getTotal() / 6+1;
        }
            model.addAttribute("currentpage",currentpage);
            model.addAttribute("pages",Pages);
            model.addAttribute("pageInfo", pageInfo);
        return "Admin/Edit";
    }

    @GetMapping("/Add")
    public String ToAdd(HttpSession session,Model model){
        return "Admin/Add";
    }
    @PostMapping(value= "/Login")
    public String Trylogin(@RequestParam String username, @RequestParam String password,HttpSession session,Model model) {
        User user = userService.checkUser(username, password);
        if (username == ""|| password== null) {
            session.setAttribute("msg","请输入用户名或密码");
            return "redirect:Admin/login";
        } else {
            if (user != null) {
                user.setPassword(null);
                session.setAttribute("user", user);
                model.addAttribute("LoadSaveBlog",false);
                session.setMaxInactiveInterval(60*60);
                return "Admin/Add";
            } else {
                session.setAttribute("msg","用户名或密码错误");
                return "redirect:Admin/login";
            }
        }
    }
    @GetMapping("/EditPage/{page}")
    public String ToMangePage(Model model,@PathVariable int page){
        PageHelper.startPage(page, 6);//开启分页
        List<Blog> blogs = blogService.getAllBlog();
        PageInfo<Blog> pageInfo = new PageInfo<>(blogs);
        Long Pages;
        if(pageInfo.getTotal()%6==0){
            Pages = pageInfo.getTotal()/6;
        }
        else {
            Pages = pageInfo.getTotal() / 6+1;
        }
        model.addAttribute("currentpage",page);
        model.addAttribute("pages",Pages);
        model.addAttribute("pageInfo", pageInfo);
    return "Admin/Edit";
    }

    @GetMapping("/Edit")
    public String ToManage(@RequestParam(required = false,defaultValue = "1",value = "pagenum")int pagenum,
                           Model model){
        PageHelper.startPage(pagenum, 6);//开启分页
        List<Blog> blogs = blogService.getAllBlog();
        PageInfo<Blog> pageInfo = new PageInfo<>(blogs);
        Long Pages;
        if(pageInfo.getTotal()%6==0){
            Pages = pageInfo.getTotal()/6;
        }
        else {
            Pages = pageInfo.getTotal() / 6+1;
        }
        model.addAttribute("currentpage",1);
        model.addAttribute("pages",Pages);
        model.addAttribute("pageInfo", pageInfo);

        return "Admin/Edit";
    }

    @GetMapping("/tags")
    public String Sorted(@RequestParam(required = false,defaultValue = "1",value = "pagenum")int pagenum,
                         Model model,@RequestParam long type){

        PageHelper.startPage(pagenum, 6);//开启分页
        List<Blog> blogs;
        if(type == 0){
            blogs = blogService.getAllBlog();
            }
        else {
            blogs = blogService.getByTypeId(type);
            }
            PageInfo<Blog> pageInfo = new PageInfo<>(blogs);
        Long Pages;
        if(pageInfo.getTotal()%6==0){
            Pages = pageInfo.getTotal()/6;
        }
        else {
            Pages = pageInfo.getTotal() / 6+1;
        }
            model.addAttribute("pages",Pages);
            model.addAttribute("currentpage",1);
            model.addAttribute("pageInfo", pageInfo);
        return "Admin/Edit";
    }


}
