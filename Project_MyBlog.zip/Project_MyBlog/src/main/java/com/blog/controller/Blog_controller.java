package com.blog.controller;

import com.blog.entity.Blog;
import com.blog.entity.Type;
import com.blog.entity.User;
import com.blog.service.BlogService;
import com.blog.service.TypeService;
import com.blog.util.Result;
import com.blog.util.ResultGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/Blogs")
public class Blog_controller {
    private ResultGenerator result;
    @Autowired
    private BlogService blogService;
    @Autowired
    private TypeService typeService;
    @GetMapping("/blogID/{id}")
    public String JumpToBlog_controller(@PathVariable Long id, Model model){
        Blog blog=blogService.getBlog(id);
        model.addAttribute("blog",blog);
        return "Blogs/BlogPage";
    }

    @ResponseBody
    @PostMapping("/AddBlog")
    public Result Input( HttpSession session
            , @RequestParam("blogtype") Long typeID
            , @RequestParam("AllowComment")Boolean AllowComment
            , @RequestParam("recommend") Boolean recommend
            , @RequestParam("blogtitle") String title
            , @RequestParam("blogcontent") String content
            , @RequestParam("published")Boolean published
    ){
        Blog blog= new Blog();
        blog.setUserId(((User) session.getAttribute("user")).getId());
        blog.setAllowComment(AllowComment);
        blog.setRecommend(recommend);
        blog.setPublished(published);
        blog.setTitle(title);
        blog.setContent(content);
        blog.setUpdateTime(new Date());
        blog.setViews(0);
        Type type=new Type();
        type.setId(typeID);
        type.setName(typeService.getTypeName(typeID));
        blog.setType(type);
        long id1=blog.getUpdateTime().getTime();
        blog.setId(id1);
        blogService.saveBlog(blog);
        return ResultGenerator.getSuccessResult("添加成功");
    }
    @ResponseBody
    @PostMapping("/UpdateBlog")
    public Result Update(RedirectAttributes attributes, HttpSession session, HttpServletRequest httpRequest
            , @RequestParam("blogtype") Long typeID
            , @RequestParam("AllowComment")Boolean AllowComment
            , @RequestParam("recommend") Boolean recommend
            , @RequestParam("blogtitle") String title
            , @RequestParam("blogcontent") String content
            , @RequestParam("published")Boolean published
            , @RequestParam("blogID")Long id
    ){
        Blog blog= new Blog();
        blog.setUserId(((User) session.getAttribute("user")).getId());
        blog.setAllowComment(AllowComment);
        blog.setRecommend(recommend);
        blog.setPublished(published);
        blog.setTitle(title);
        blog.setContent(content);
        blog.setUpdateTime(new Date());
        blog.setViews(0);
        Type type=new Type();
        type.setId(typeID);
        type.setName(typeService.getTypeName(typeID));
        blog.setType(type);
        blogService.updateBlog(blog,id);
        return ResultGenerator.getSuccessResult("更新成功");
    }
    @ResponseBody
    @PostMapping("/del")
    public Result delete(@RequestParam("id") Long id){
        blogService.deleteBlog(id);
        return ResultGenerator.getSuccessResult("删除成功");
    }

    @GetMapping("/LoadSaveBlog")
    public String LoadSaveBolg(HttpSession session, HttpServletRequest request)
        {
        User user= (User) session.getAttribute("user");
        Blog saveblog=blogService.getBlog(user.getBlog_save());
        return "Admin/Update";
        }
        @GetMapping("/Update/{blogID}")
        public String Update(@PathVariable("blogID") Long id){
            System.out.println(id);
        return "Admin/Update";
        }
}
