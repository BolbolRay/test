package com.blog.service.implement;

import com.blog.DAO.TypeDao;
import com.blog.entity.Type;
import com.blog.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TypeServiceImpl implements TypeService {
    @Autowired
    private TypeDao typedao;//注入数据库获取的Type对象

    @Override
    public Type getType(Long id) {
        return typedao.getType(id);
    }



    @Override
    public String getTypeName(Long id) {
        return typedao.getTypeName(id);
    }

    @Override
    public List<Type> getAllType() {
        return typedao.getAllType();
    }
    @Override
    public List<Type> getBlogType() {
        return typedao.getBlogType();
    }
}
