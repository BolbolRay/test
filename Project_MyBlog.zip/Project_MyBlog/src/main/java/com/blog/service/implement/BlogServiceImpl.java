package com.blog.service.implement;

import com.blog.DAO.BlogDao;
import com.blog.DAO.TypeDao;
import com.blog.entity.Blog;
import com.blog.entity.SearchResult;
import com.blog.entity.Type;
import com.blog.service.BlogService;
import com.blog.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class BlogServiceImpl implements BlogService {
    @Autowired
    BlogDao blogDao;

    @Override
    public Blog getBlog(Long id) {
        return blogDao.getBlog(id);
    }

    @Override
    public Blog getDetailedBlog(Long id) {
        return null;
    }

    @Override
    public List<Blog> getAllBlog() {
        return blogDao.getAllBlog();
    }

    @Override
    public List<Blog> getByTypeId(Long typeId) {
        return blogDao.getByTypeId(typeId);
    }

    @Override
    public List<Blog> getSearchResults(String query) {

        List<SearchResult> TitleAndID=blogDao.getTitleAndID();
        int priority=0;
        int QueryLength=query.length();
        LinkedList<Integer> PriorityList=new LinkedList<>();
        //给每个博客赋予权值
        for(int i=0;i<TitleAndID.size(); i++){
            int TitleLength=TitleAndID.get(i).getTitle().length();
            for(int x=0,y=0;x<TitleLength;x++){
                if(y>=QueryLength)break;
                if((TitleAndID.get(i).getTitle().charAt(x) == query.charAt(y))){
                    //符合搜索条件
                    priority++;
                    y++;
                }
                else {
                  y=0;
                }
            }
            PriorityList.add(priority);
            priority=0;
        }
        List<Blog> Blogs=SearchResults(PriorityList ,TitleAndID);

        return Blogs;
    }

    public List<Blog> SearchResults(LinkedList<Integer> PriorityList,List<SearchResult> TitleAndID){
        List<Blog> Blogs = new ArrayList<>();
        int MaxPrior=0;int MaxPriorID=0;
        for(int i = 0; i <5;i++){
        for(int j = 0; j <PriorityList.size(); j++){
            if(PriorityList.get(j)>=(MaxPrior)){
                MaxPrior=PriorityList.get(j);
                MaxPriorID=j;
                }
            }
            if(MaxPrior!=0)
                Blogs.add(blogDao.getBlog(TitleAndID.get(MaxPriorID).getId()));
            PriorityList.remove(MaxPriorID);
            TitleAndID.remove(MaxPriorID);
            MaxPrior=0;
        }
        return Blogs;
    }
    @Override
    public List<Blog> getIndexBlog() {
        return blogDao.getIndexBlog();
    }

    @Override
    public List<Blog> getAllRecommendBlog() {
        return blogDao.getAllRecommendBlog();
    }


    @Override
    public Map<String, List<Blog>> archiveBlog() {
        List<String> years = blogDao.findGroupYear();
        Set<String> set = new HashSet<>(years);  //set去掉重复的年份
        Map<String, List<Blog>> map = new HashMap<>();
        for (String year : set) {
            map.put(year, blogDao.findByYear(year));
        }
        return map;
    }

    @Override
    public int countBlog() {
        return blogDao.getAllBlog().size();
    }

    @Override
    public int saveBlog(Blog blog) {
        return blogDao.saveBlog(blog);
    }

    @Override
    public Blog updateBlog(Blog blog,Long id) {
        blogDao.getBlog(id);

        return null;
    }

    @Override
    public List<Blog> searchAllBlog(Blog blog) {
        return blogDao.searchAllBlog(blog);
    }




    @Override
    public int deleteBlog(Long id) {
        return blogDao.deleteBlog(id);
    }
}
