package com.blog.service;

import com.blog.entity.Type;

import java.util.List;

public interface TypeService {

    Type getType(Long id);//根据id查询某个类

    String getTypeName(Long id);


    List<Type> getAllType();

    List<Type> getBlogType();  //首页右侧展示type对应的博客数量

}
