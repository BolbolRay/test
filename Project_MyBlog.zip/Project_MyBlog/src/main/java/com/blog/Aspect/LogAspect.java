package com.blog.Aspect;

import lombok.Data;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/*
* 关于日志的切面
* */
@Aspect
@Component
public class LogAspect {
    private final Logger logger= LoggerFactory.getLogger(this.getClass());
    //切入点，execution中的参数是拦截的方法，需要精细到在哪个包下哪个类的方法
    //第一个*是方法返回值
    @Pointcut("execution(* com.blog.controller.*.*(..))")
    public void log(){

    }

    @Before("log()")
    public void doBefore(JoinPoint joinPoint){
        ServletRequestAttributes attributes= (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request=attributes.getRequest();
        String url=request.getRequestURL().toString();
        String ip=request.getRemoteAddr();
        String classmethod=joinPoint.getSignature().getDeclaringTypeName() + "."+joinPoint.getSignature().getName();
        RequestLog requestLog = new RequestLog(url,ip,classmethod);
        logger.info("Request: {}",requestLog);
    }

    @After("log()")
    public void doAfter() {
        logger.info("-------------doAfter------------");
    }
    //方法返回类型
    @AfterReturning(returning = "result",pointcut = "log()")
    public void doAfterReturning(Object result){
        logger.info("Result: {}",result);
    }

    @Data
    private class RequestLog{
        private String url;
        private String ip;
        private String classMethod;

        public RequestLog(String url,String ip,String classMethod){
            this.url = url;
            this.ip = ip;
            this.classMethod = classMethod;
        }

    }
}
