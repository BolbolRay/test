package com.blog.DAO;

import com.blog.entity.Type;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface TypeDao {
    Type getType(Long id);

    String getTypeName(Long id);

    List<Type> getAllType();

    List<Type> getBlogType();
}
