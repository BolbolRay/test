var blogEditor;
// Tags Input

//Initialize Select2 Elements


$(function () {
    blogEditor = editormd("blog-editormd", {
        width: "100%",
        height: 640,
        syncScrolling: "single",
        path: "/lib/MarkDown/lib/",
        toolbarModes: 'full',
        /**图片上传配置*/
        imageUpload: true,
        imageFormats: ["jpg", "jpeg", "gif", "png", "bmp", "webp"], //图片上传格式
        onload: function (obj) { //上传成功之后的回调
        }
    });})

